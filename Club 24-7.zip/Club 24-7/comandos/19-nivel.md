# 19. Niveles y XP

Comando base: `/nivel`

## 1. /nivel rank

Ver tu nivel y XP

Permiso: Ninguno

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| usuario | usuario | No | — |

## 2. /nivel top

Top de niveles

Permiso: Ninguno

Sin opciones.

## 3. /nivel set

Establece el nivel de un usuario

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| usuario | usuario | Sí | — |
| nivel | número entero | Sí | — |

## 4. /nivel xpadd

Da XP a un usuario

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| usuario | usuario | Sí | — |
| cantidad | número entero | Sí | — |

## 5. /nivel xpremove

Quita XP a un usuario

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| usuario | usuario | Sí | — |
| cantidad | número entero | Sí | — |

## 6. /nivel rate

XP medio por mensaje (1-100)

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| cantidad | número entero | Sí | — |

## 7. /nivel canal

Canal de avisos de nivel

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| canal | canal | No | — |

## 8. /nivel roladd

Rol de recompensa por nivel

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| nivel | número entero | Sí | — |
| rol | rol | Sí | — |

## 9. /nivel rolremove

Quita rol de recompensa

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| nivel | número entero | Sí | — |

## 10. /nivel roles

Ver roles de recompensa

Permiso: Ninguno

Sin opciones.

## 11. /nivel mensaje

Mensaje/imagen de subida. {user} {level} {server}

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| texto | texto | No | — |
| imagen | texto | No | — |
| titulo | texto | No | — |

## 12. /nivel reset

Reinicia niveles de un usuario

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| usuario | usuario | Sí | — |

## 13. /nivel toggle

Activa/desactiva el sistema de niveles

Permiso: `Administrator`

| Opción | Tipo | Obligatoria | Opciones fijas |
|---|---|---|---|
| estado | sí/no | Sí | — |
