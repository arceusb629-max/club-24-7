# 11. Enlaces del bot

Comando base: `/links`

## 1. /links ver

Muestra el enlace para invitar al bot y el dashboard

Permiso: Ninguno

Sin opciones.
